import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const rules = await prisma.recurringRule.findMany({
            where: { userId: user.id },
            include: { category: true },
            orderBy: { nextDueDate: "asc" },
        });

        return NextResponse.json(rules);
    } catch (err) {
        console.error("[api/recurring] GET error:", err);
        return NextResponse.json([]);
    }
}

export async function POST(req: NextRequest) {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();

    const rule = await prisma.recurringRule.create({
        data: {
            userId: user.id,
            type: body.type || "bill",
            cadence: body.cadence || "monthly",
            amount: body.amount,
            merchant: body.merchant || null,
            description: body.description || null,
            upiVpa: body.upiVpa || null,
            nextDueDate: body.nextDueDate ? new Date(body.nextDueDate) : null,
            categoryId: body.categoryId || null,
        },
        include: { category: true },
    });

    return NextResponse.json(rule, { status: 201 });
}
