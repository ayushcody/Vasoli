import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

/**
 * GET /api/dedup — Find probable duplicate transactions
 * Same amount, date ±1 day, similar merchant, different source
 */
export async function GET() {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const transactions = await prisma.transaction.findMany({
            where: { userId: user.id },
            orderBy: { date: "desc" },
            take: 500,
        });

        const groups: { a: typeof transactions[0]; b: typeof transactions[0]; reason: string }[] = [];

        for (let i = 0; i < transactions.length; i++) {
            for (let j = i + 1; j < transactions.length; j++) {
                const a = transactions[i];
                const b = transactions[j];

                if (a.provenance === b.provenance && a.importBatchId === b.importBatchId) continue;
                if (Math.abs(a.amount - b.amount) > 0.01) continue;

                const daysDiff = Math.abs(a.date.getTime() - b.date.getTime()) / (1000 * 60 * 60 * 24);
                if (daysDiff > 1.5) continue;

                const reasons: string[] = [];
                reasons.push(`Same amount: ₹${a.amount}`);
                if (daysDiff < 0.01) reasons.push("Same date");
                else reasons.push(`Date ±${Math.round(daysDiff)} day`);

                if (a.merchantNorm && b.merchantNorm && a.merchantNorm === b.merchantNorm) {
                    reasons.push("Same merchant");
                }

                groups.push({ a, b, reason: reasons.join(", ") });
            }
        }

        return NextResponse.json(groups.slice(0, 20));
    } catch (err) {
        console.error("[api/dedup] GET error:", err);
        return NextResponse.json([]);
    }
}
