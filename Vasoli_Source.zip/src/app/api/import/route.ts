import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { parseGenericCSV, type ColumnMapping } from "@/lib/parsers/csv-generic";
import { parseHDFCStatement } from "@/lib/parsers/hdfc-statement";
import type { ParsedTransaction } from "@/lib/parsers/merchant";
import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";

export async function POST(req: NextRequest) {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const format = formData.get("format") as string; // "hdfc" | "generic"
    const mappingJson = formData.get("mapping") as string | null; // JSON for generic

    if (!file) {
        return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const text = await file.text();
    const fileHash = crypto.createHash("sha256").update(text).digest("hex");

    // Check for duplicate import
    const existingBatch = await prisma.importBatch.findFirst({
        where: { userId: user.id, fileHash },
    });
    if (existingBatch) {
        return NextResponse.json(
            { error: "This file has already been imported", batchId: existingBatch.id },
            { status: 409 }
        );
    }

    // Parse based on format
    let parsed: ParsedTransaction[];
    try {
        if (format === "hdfc") {
            parsed = parseHDFCStatement(text);
        } else {
            const mapping: ColumnMapping = mappingJson
                ? JSON.parse(mappingJson)
                : { date: "Date", description: "Description", debit: "Debit", credit: "Credit" };
            parsed = parseGenericCSV(text, mapping);
        }
    } catch (e: any) {
        return NextResponse.json({ error: `Parse error: ${e.message}` }, { status: 400 });
    }

    if (parsed.length === 0) {
        return NextResponse.json({ error: "No transactions found in file" }, { status: 400 });
    }

    // Create import batch
    const batch = await prisma.importBatch.create({
        data: {
            userId: user.id,
            sourceType: "statement_csv",
            bankName: format === "hdfc" ? "HDFC" : (formData.get("bankName") as string) || null,
            fileName: file.name,
            fileHash,
            recordCount: parsed.length,
        },
    });

    // Try to match against existing transactions
    let matchedCount = 0;
    const created: string[] = [];

    for (const p of parsed) {
        // Check for existing match: same amount, date ±1 day, similar merchant
        const dayBefore = new Date(p.date);
        dayBefore.setDate(dayBefore.getDate() - 1);
        const dayAfter = new Date(p.date);
        dayAfter.setDate(dayAfter.getDate() + 1);

        const potentialMatch = await prisma.transaction.findFirst({
            where: {
                userId: user.id,
                amount: p.amount,
                type: p.type,
                date: { gte: dayBefore, lte: dayAfter },
                status: "pending", // only match pending transactions
            },
        });

        if (potentialMatch) {
            // Update the pending transaction to posted
            await prisma.transaction.update({
                where: { id: potentialMatch.id },
                data: {
                    status: "posted",
                    importBatchId: batch.id,
                    merchantRaw: potentialMatch.merchantRaw || p.merchantRaw,
                    merchantNorm: potentialMatch.merchantNorm || p.merchantNorm,
                    upiRef: p.upiRef || potentialMatch.upiRef,
                },
            });

            await prisma.transactionEvent.create({
                data: {
                    userId: user.id,
                    transactionId: potentialMatch.id,
                    type: "status_change",
                    payloadJson: JSON.stringify({
                        from: "pending",
                        to: "posted",
                        importBatchId: batch.id,
                    }),
                },
            });

            matchedCount++;
        } else {
            // Create new transaction
            const txn = await prisma.transaction.create({
                data: {
                    userId: user.id,
                    date: p.date,
                    amount: p.amount,
                    type: p.type,
                    merchantRaw: p.merchantRaw,
                    merchantNorm: p.merchantNorm,
                    description: p.description,
                    status: "posted",
                    provenance: "statement_import",
                    importBatchId: batch.id,
                    upiRef: p.upiRef || null,
                },
            });

            await prisma.transactionEvent.create({
                data: {
                    userId: user.id,
                    transactionId: txn.id,
                    type: "created",
                    payloadJson: JSON.stringify({
                        provenance: "statement_import",
                        importBatchId: batch.id,
                    }),
                },
            });

            created.push(txn.id);
        }
    }

    // Update batch with match count
    await prisma.importBatch.update({
        where: { id: batch.id },
        data: { matchedCount },
    });

    return NextResponse.json({
        batchId: batch.id,
        totalParsed: parsed.length,
        created: created.length,
        matched: matchedCount,
        duplicateSuggestions: 0, // Phase 4 will add dedup
    });
}

export async function GET(req: NextRequest) {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const batches = await prisma.importBatch.findMany({
        where: { userId: user.id },
        orderBy: { importedAt: "desc" },
        take: 20,
    });

    return NextResponse.json(batches);
}
