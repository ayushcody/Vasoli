import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

/** GET /api/zine/[period] — Deterministic monthly insights */
export async function GET(
    req: NextRequest,
    { params }: { params: { period: string } }
) {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const [year, month] = params.period.split("-").map(Number);
        if (!year || !month) {
            return NextResponse.json({ error: "Invalid period format, use YYYY-MM" }, { status: 400 });
        }

        const startDate = new Date(year, month - 1, 1);
        const endDate = new Date(year, month, 0, 23, 59, 59);

        // Previous month for comparison
        const prevStart = new Date(year, month - 2, 1);
        const prevEnd = new Date(year, month - 1, 0, 23, 59, 59);

        const [transactions, prevTransactions] = await Promise.all([
            prisma.transaction.findMany({
                where: { userId: user.id, date: { gte: startDate, lte: endDate } },
                include: { category: true },
            }),
            prisma.transaction.findMany({
                where: { userId: user.id, date: { gte: prevStart, lte: prevEnd } },
                include: { category: true },
            }),
        ]);

        const expenses = transactions.filter((t) => t.type === "EXPENSE");
        const prevExpenses = prevTransactions.filter((t) => t.type === "EXPENSE");

        // Top 3 categories by spend
        const categorySpend: Record<string, { name: string; icon: string; total: number }> = {};
        for (const t of expenses) {
            const cat = t.category?.name || "Uncategorized";
            if (!categorySpend[cat]) categorySpend[cat] = { name: cat, icon: t.category?.icon || "📝", total: 0 };
            categorySpend[cat].total += t.amount;
        }
        const topCategories = Object.values(categorySpend)
            .sort((a, b) => b.total - a.total)
            .slice(0, 3);

        // Biggest one-off spend
        const biggestSpend = expenses.length > 0
            ? expenses.reduce((max, t) => (t.amount > max.amount ? t : max), expenses[0])
            : null;

        // Total spent this month vs last
        const totalSpent = expenses.reduce((s, t) => s + t.amount, 0);
        const prevTotalSpent = prevExpenses.reduce((s, t) => s + t.amount, 0);
        const savedVsPrev = prevTotalSpent - totalSpent;

        // Unique days with transactions (streak proxy)
        const uniqueDays = new Set(transactions.map((t) => t.date.toISOString().slice(0, 10)));
        const streak = uniqueDays.size;

        // Category overshoot (biggest increase vs previous month)
        const prevCategorySpend: Record<string, number> = {};
        for (const t of prevExpenses) {
            const cat = t.category?.name || "Uncategorized";
            prevCategorySpend[cat] = (prevCategorySpend[cat] || 0) + t.amount;
        }
        let leak: { category: string; increase: number } | null = null;
        for (const [cat, data] of Object.entries(categorySpend)) {
            const prev = prevCategorySpend[cat] || 0;
            const increase = data.total - prev;
            if (!leak || increase > leak.increase) {
                leak = { category: cat, increase };
            }
        }

        return NextResponse.json({
            period: params.period,
            totalSpent,
            totalIncome: transactions.filter((t) => t.type === "INCOME").reduce((s, t) => s + t.amount, 0),
            transactionCount: transactions.length,
            topCategories,
            biggestSpend: biggestSpend
                ? { merchant: biggestSpend.merchantRaw, amount: biggestSpend.amount, date: biggestSpend.date }
                : null,
            streak,
            savedVsPrev,
            leak: leak && leak.increase > 0 ? leak : null,
        });
    } catch (err) {
        console.error("[api/zine] GET error:", err);
        return NextResponse.json({
            period: params.period,
            totalSpent: 0,
            totalIncome: 0,
            transactionCount: 0,
            topCategories: [],
            biggestSpend: null,
            streak: 0,
            savedVsPrev: 0,
            leak: null,
        });
    }
}
