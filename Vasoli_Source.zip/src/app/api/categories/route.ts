import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
    try {
        const categories = await prisma.category.findMany({
            orderBy: [{ type: "asc" }, { name: "asc" }],
        });
        return NextResponse.json(categories);
    } catch (err) {
        console.error("[api/categories] GET error:", err);
        return NextResponse.json([]);
    }
}
