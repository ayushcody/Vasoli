import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextRequest } from "next/server";
import { getGenAI, MARCO_MODEL, MARCO_TOOL_DECLARATIONS } from "@/lib/marco/gemini";
import { MARCO_SYSTEM_PROMPT } from "@/lib/marco/system-prompt";
import { executeTool, type ToolName } from "@/lib/marco/tools";
import { Content, Part, FunctionCall } from "@google/genai";

// POST /api/marco/chat — main chat endpoint with SSE streaming + function calling
export async function POST(req: NextRequest) {
    try {
        // ─── Auth ────────────────────────────────────────────────
        const supabase = createClient();
        const {
            data: { user },
        } = await supabase.auth.getUser();
        if (!user) {
            return new Response(JSON.stringify({ error: "Unauthorized" }), {
                status: 401,
                headers: { "Content-Type": "application/json" },
            });
        }

        // ─── Parse request ───────────────────────────────────────
        const body = await req.json();
        const { threadId, message } = body;

        if (!threadId || !message) {
            return new Response(
                JSON.stringify({ error: "threadId and message are required" }),
                { status: 400, headers: { "Content-Type": "application/json" } }
            );
        }

        // ─── Verify thread ownership ─────────────────────────────
        const thread = await prisma.marcoThread.findFirst({
            where: { id: threadId, userId: user.id },
        });
        if (!thread) {
            return new Response(JSON.stringify({ error: "Thread not found" }), {
                status: 404,
                headers: { "Content-Type": "application/json" },
            });
        }

        // ─── Save user message ───────────────────────────────────
        await prisma.marcoMessage.create({
            data: {
                threadId,
                role: "user",
                content: message,
            },
        });

        // ─── Load conversation history (last 20 messages) ───────
        const history = await prisma.marcoMessage.findMany({
            where: { threadId },
            orderBy: { createdAt: "asc" },
            take: 20,
        });

        // Convert DB messages to Gemini Content format
        const geminiHistory: Content[] = history
            .filter((m: { role: string }) => m.role === "user" || m.role === "assistant")
            .map((m: { role: string; partsJson: string | null; content: string }) => ({
                role: m.role === "assistant" ? ("model" as const) : ("user" as const),
                parts: m.partsJson
                    ? (JSON.parse(m.partsJson) as Part[])
                    : [{ text: m.content }],
            }));

        // ─── SSE Stream response ─────────────────────────────────
        const encoder = new TextEncoder();
        const stream = new ReadableStream({
            async start(controller) {
                try {
                    let finalText = "";
                    let finalPartsJson: string | null = null;

                    // Tool-calling loop (max 5 iterations)
                    let contents: Content[] = [...geminiHistory];
                    let toolCallCount = 0;

                    while (toolCallCount < 5) {
                        const response = await getGenAI().models.generateContent({
                            model: MARCO_MODEL,
                            contents,
                            config: {
                                systemInstruction: MARCO_SYSTEM_PROMPT,
                                tools: [{ functionDeclarations: MARCO_TOOL_DECLARATIONS }],
                            },
                        });

                        const candidate = response.candidates?.[0];
                        if (!candidate?.content?.parts) break;

                        const parts = candidate.content.parts;

                        // Check for function calls
                        const functionCalls = parts.filter(
                            (p: Part): p is Part & { functionCall: FunctionCall } =>
                                p.functionCall !== undefined
                        );

                        if (functionCalls.length > 0) {
                            // Execute each tool call
                            toolCallCount++;

                            // Add model's response (with function calls) to history
                            contents.push({
                                role: "model",
                                parts: parts,
                            });

                            // Execute tools and add results
                            for (const fc of functionCalls) {
                                const toolName = fc.functionCall.name as ToolName;
                                const toolArgs = (fc.functionCall.args as Record<string, any>) || {};

                                // Send tool usage indicator to client
                                controller.enqueue(
                                    encoder.encode(
                                        `data: ${JSON.stringify({ type: "tool_use", tool: toolName })}\n\n`
                                    )
                                );

                                const result = await executeTool(toolName, user.id, toolArgs);

                                contents.push({
                                    role: "user",
                                    parts: [
                                        {
                                            functionResponse: {
                                                name: toolName,
                                                response: result,
                                            },
                                        },
                                    ],
                                });
                            }

                            // Continue the loop to get the final text response
                            continue;
                        }

                        // No function calls — extract text and stream it
                        const textParts = parts.filter((p: Part) => p.text);
                        const fullText = textParts.map((p: Part) => p.text || "").join("");
                        finalText = fullText;
                        finalPartsJson = JSON.stringify(parts);

                        // Stream the text in chunks for smooth UI
                        const words = fullText.split(" ");
                        for (let i = 0; i < words.length; i++) {
                            const chunk = (i === 0 ? "" : " ") + words[i];
                            controller.enqueue(
                                encoder.encode(
                                    `data: ${JSON.stringify({ type: "text", content: chunk })}\n\n`
                                )
                            );
                            // Small delay for streaming effect
                            await new Promise((r) => setTimeout(r, 15));
                        }

                        break;
                    }

                    // ─── Save assistant message ──────────────────────────
                    if (finalText) {
                        await prisma.marcoMessage.create({
                            data: {
                                threadId,
                                role: "assistant",
                                content: finalText,
                                partsJson: finalPartsJson,
                            },
                        });

                        // Update thread title if it's the first exchange
                        const messageCount = await prisma.marcoMessage.count({
                            where: { threadId },
                        });

                        if (messageCount <= 2) {
                            // Auto-generate title from user's first message
                            const title =
                                message.length > 50
                                    ? message.slice(0, 47) + "..."
                                    : message;
                            await prisma.marcoThread.update({
                                where: { id: threadId },
                                data: { title, lastMessageAt: new Date() },
                            });
                        } else {
                            await prisma.marcoThread.update({
                                where: { id: threadId },
                                data: { lastMessageAt: new Date() },
                            });
                        }
                    }

                    // Send done signal
                    controller.enqueue(
                        encoder.encode(`data: ${JSON.stringify({ type: "done" })}\n\n`)
                    );
                    controller.close();
                } catch (err) {
                    console.error("[marco/chat] Stream error:", err);
                    controller.enqueue(
                        encoder.encode(
                            `data: ${JSON.stringify({
                                type: "error",
                                content: "Sorry, something went wrong. Please try again.",
                            })}\n\n`
                        )
                    );
                    controller.close();
                }
            },
        });

        return new Response(stream, {
            headers: {
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
                Connection: "keep-alive",
            },
        });
    } catch (err) {
        console.error("[marco/chat] Error:", err);
        return new Response(
            JSON.stringify({ error: "Internal server error" }),
            { status: 500, headers: { "Content-Type": "application/json" } }
        );
    }
}
