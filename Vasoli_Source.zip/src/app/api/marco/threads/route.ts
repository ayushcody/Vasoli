import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// GET /api/marco/threads — list user's threads
export async function GET() {
    try {
        const supabase = createClient();
        const {
            data: { user },
        } = await supabase.auth.getUser();
        if (!user)
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const threads = await prisma.marcoThread.findMany({
            where: { userId: user.id },
            orderBy: { lastMessageAt: "desc" },
            select: {
                id: true,
                title: true,
                lastMessageAt: true,
                createdAt: true,
                _count: { select: { messages: true } },
            },
            take: 50,
        });

        return NextResponse.json(threads);
    } catch (err) {
        console.error("[marco/threads GET]", err);
        return NextResponse.json([]);
    }
}

// POST /api/marco/threads — create new thread
export async function POST() {
    try {
        const supabase = createClient();
        const {
            data: { user },
        } = await supabase.auth.getUser();
        if (!user)
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const thread = await prisma.marcoThread.create({
            data: {
                userId: user.id,
                title: "New chat",
            },
        });

        return NextResponse.json(thread, { status: 201 });
    } catch (err) {
        console.error("[marco/threads POST]", err);
        return NextResponse.json(
            { error: "Database unavailable. Please try again later." },
            { status: 503 }
        );
    }
}
