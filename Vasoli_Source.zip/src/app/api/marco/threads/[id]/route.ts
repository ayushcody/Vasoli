import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

// GET /api/marco/threads/[id] — get thread with messages
export async function GET(
    _req: Request,
    { params }: { params: { id: string } }
) {
    try {
        const supabase = createClient();
        const {
            data: { user },
        } = await supabase.auth.getUser();
        if (!user)
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const thread = await prisma.marcoThread.findFirst({
            where: { id: params.id, userId: user.id },
            include: {
                messages: {
                    orderBy: { createdAt: "asc" },
                },
            },
        });

        if (!thread) {
            return NextResponse.json({ error: "Thread not found" }, { status: 404 });
        }

        return NextResponse.json(thread);
    } catch (err) {
        console.error("[marco/threads/[id] GET]", err);
        return NextResponse.json(
            { error: "Failed to fetch thread" },
            { status: 500 }
        );
    }
}

// DELETE /api/marco/threads/[id]
export async function DELETE(
    _req: Request,
    { params }: { params: { id: string } }
) {
    try {
        const supabase = createClient();
        const {
            data: { user },
        } = await supabase.auth.getUser();
        if (!user)
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        // Verify ownership before deleting
        const thread = await prisma.marcoThread.findFirst({
            where: { id: params.id, userId: user.id },
        });

        if (!thread) {
            return NextResponse.json({ error: "Thread not found" }, { status: 404 });
        }

        await prisma.marcoThread.delete({ where: { id: params.id } });

        return NextResponse.json({ deleted: true });
    } catch (err) {
        console.error("[marco/threads/[id] DELETE]", err);
        return NextResponse.json(
            { error: "Failed to delete thread" },
            { status: 500 }
        );
    }
}
