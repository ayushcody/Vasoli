import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

/**
 * POST /api/dev/seed
 * Populates the authenticated user's account with rich demo data.
 * This is intended for development/demo purposes only.
 */
export async function POST() {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const userId = user.id;

        // 1. Upsert default categories
        const categoryData = [
            { name: "Food & Dining", icon: "🍛", color: "#F6DD4D", type: "EXPENSE", isDefault: true },
            { name: "Groceries", icon: "🛒", color: "#2EC4B6", type: "EXPENSE", isDefault: true },
            { name: "Transport", icon: "🚌", color: "#3D5AFE", type: "EXPENSE", isDefault: true },
            { name: "Rent", icon: "🏠", color: "#FD712C", type: "EXPENSE", isDefault: true },
            { name: "Utilities", icon: "💡", color: "#8B5CF6", type: "EXPENSE", isDefault: true },
            { name: "Mobile & Internet", icon: "📱", color: "#FF4D8D", type: "EXPENSE", isDefault: true },
            { name: "Shopping", icon: "🛍️", color: "#E63946", type: "EXPENSE", isDefault: true },
            { name: "Education", icon: "📚", color: "#3D5AFE", type: "EXPENSE", isDefault: true },
            { name: "Medical", icon: "🏥", color: "#E63946", type: "EXPENSE", isDefault: true },
            { name: "Entertainment", icon: "🎬", color: "#8B5CF6", type: "EXPENSE", isDefault: true },
            { name: "Subscriptions", icon: "🔄", color: "#FD712C", type: "EXPENSE", isDefault: true },
            { name: "Other Expense", icon: "📝", color: "#A2897D", type: "EXPENSE", isDefault: true },
            { name: "Salary", icon: "💰", color: "#2EC4B6", type: "INCOME", isDefault: true },
            { name: "Freelance", icon: "💻", color: "#3D5AFE", type: "INCOME", isDefault: true },
            { name: "Cashback & Rewards", icon: "🎉", color: "#FD712C", type: "INCOME", isDefault: true },
            { name: "Other Income", icon: "📥", color: "#A2897D", type: "INCOME", isDefault: true },
        ];

        const categories: Record<string, string> = {};
        for (const cat of categoryData) {
            const created = await prisma.category.upsert({
                where: { name: cat.name },
                update: {},
                create: cat,
            });
            categories[cat.name] = created.id;
        }

        // 2. Create demo transactions (last 60 days)
        const now = new Date();
        const demoTransactions = [
            { desc: "Swiggy - Chicken Biryani", amount: 349, type: "EXPENSE", cat: "Food & Dining", daysAgo: 1, upi: "swiggy@upi" },
            { desc: "Zepto Groceries", amount: 892, type: "EXPENSE", cat: "Groceries", daysAgo: 2, upi: "zepto@ybl" },
            { desc: "Uber Auto to Office", amount: 187, type: "EXPENSE", cat: "Transport", daysAgo: 2, upi: "uber@paytm" },
            { desc: "Netflix Subscription", amount: 649, type: "EXPENSE", cat: "Subscriptions", daysAgo: 3, upi: null },
            { desc: "Amazon - Wireless earbuds", amount: 2499, type: "EXPENSE", cat: "Shopping", daysAgo: 4, upi: "amazon@apl" },
            { desc: "March Salary", amount: 85000, type: "INCOME", cat: "Salary", daysAgo: 5, upi: null },
            { desc: "Electricity Bill - Tata Power", amount: 1450, type: "EXPENSE", cat: "Utilities", daysAgo: 6, upi: "tatapower@upi" },
            { desc: "Jio Recharge", amount: 666, type: "EXPENSE", cat: "Mobile & Internet", daysAgo: 7, upi: "jio@icici" },
            { desc: "DMart Weekly Groceries", amount: 2340, type: "EXPENSE", cat: "Groceries", daysAgo: 8, upi: null },
            { desc: "Ola Ride to Airport", amount: 560, type: "EXPENSE", cat: "Transport", daysAgo: 9, upi: "ola@ybl" },
            { desc: "PVR Movie Tickets x2", amount: 700, type: "EXPENSE", cat: "Entertainment", daysAgo: 10, upi: "pvr@paytm" },
            { desc: "Chai Point - Office", amount: 120, type: "EXPENSE", cat: "Food & Dining", daysAgo: 11, upi: "chaipoint@upi" },
            { desc: "Apollo Pharmacy", amount: 450, type: "EXPENSE", cat: "Medical", daysAgo: 12, upi: "apollo@ybl" },
            { desc: "Coursera Subscription", amount: 3499, type: "EXPENSE", cat: "Education", daysAgo: 13, upi: null },
            { desc: "Freelance Project - Logo Design", amount: 15000, type: "INCOME", cat: "Freelance", daysAgo: 14, upi: null },
            { desc: "Zara - Jacket", amount: 3999, type: "EXPENSE", cat: "Shopping", daysAgo: 15, upi: null },
            { desc: "Myntra - Shoes", amount: 2199, type: "EXPENSE", cat: "Shopping", daysAgo: 17, upi: "myntra@ybl" },
            { desc: "Dominos Pizza", amount: 525, type: "EXPENSE", cat: "Food & Dining", daysAgo: 18, upi: "dominos@paytm" },
            { desc: "CRED Cashback", amount: 200, type: "INCOME", cat: "Cashback & Rewards", daysAgo: 19, upi: "cred@axl" },
            { desc: "BigBasket Order", amount: 1780, type: "EXPENSE", cat: "Groceries", daysAgo: 20, upi: "bigbasket@ybl" },
            { desc: "Uber to Mall", amount: 245, type: "EXPENSE", cat: "Transport", daysAgo: 22, upi: "uber@paytm" },
            { desc: "Spotify Premium", amount: 119, type: "EXPENSE", cat: "Subscriptions", daysAgo: 25, upi: null },
            { desc: "February Salary", amount: 85000, type: "INCOME", cat: "Salary", daysAgo: 35, upi: null },
            { desc: "Water Bill", amount: 350, type: "EXPENSE", cat: "Utilities", daysAgo: 37, upi: "waterbill@upi" },
            { desc: "Starbucks Coffee", amount: 380, type: "EXPENSE", cat: "Food & Dining", daysAgo: 40, upi: "starbucks@paytm" },
            { desc: "Flipkart - Phone Case", amount: 599, type: "EXPENSE", cat: "Shopping", daysAgo: 42, upi: "flipkart@ybl" },
            { desc: "PhonePe Cashback", amount: 50, type: "INCOME", cat: "Cashback & Rewards", daysAgo: 45, upi: "phonepe@ybl" },
            { desc: "Gym Membership", amount: 2500, type: "EXPENSE", cat: "Other Expense", daysAgo: 48, upi: "gym@upi" },
            { desc: "Reliance Digital - Adapter", amount: 799, type: "EXPENSE", cat: "Shopping", daysAgo: 50, upi: null },
            { desc: "Paytm Recharge Cashback", amount: 30, type: "INCOME", cat: "Cashback & Rewards", daysAgo: 55, upi: "paytm@paytm" },
        ];

        for (const t of demoTransactions) {
            const txDate = new Date(now);
            txDate.setDate(txDate.getDate() - t.daysAgo);

            await prisma.transaction.create({
                data: {
                    userId,
                    amount: t.amount,
                    description: t.desc,
                    merchantRaw: t.desc.split(" - ")[0] || t.desc,
                    date: txDate,
                    type: t.type,
                    upiRef: t.upi,
                    provenance: "manual",
                    status: "posted",
                    categoryId: categories[t.cat] || null,
                },
            });
        }

        // 3. Create demo goals
        const demoGoals = [
            { name: "Emergency Fund", desc: "6 months of expenses", target: 300000, current: 87000, icon: "🛡️", color: "#E63946" },
            { name: "Goa Trip", desc: "Weekend trip with friends", target: 25000, current: 18500, icon: "✈️", color: "#2EC4B6" },
            { name: "New MacBook", desc: "M4 Pro for development", target: 200000, current: 45000, icon: "💻", color: "#3D5AFE" },
            { name: "Wedding Gift", desc: "Best friend's wedding", target: 10000, current: 10000, icon: "💍", color: "#F6DD4D", active: false },
        ];

        for (const g of demoGoals) {
            await prisma.goal.create({
                data: {
                    userId,
                    name: g.name,
                    description: g.desc,
                    targetAmount: g.target,
                    currentAmount: g.current,
                    icon: g.icon,
                    color: g.color,
                    active: g.active ?? true,
                    dueDate: new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000), // 90 days from now
                },
            });
        }

        // 4. Create demo receipts
        const demoReceipts = [
            { merchant: "Amazon India", amount: 2499, returnBy: 15, warranty: 365 },
            { merchant: "Reliance Digital", amount: 799, returnBy: 7, warranty: 180 },
            { merchant: "Flipkart", amount: 599, returnBy: 10, warranty: null },
        ];

        for (const r of demoReceipts) {
            await prisma.receipt.create({
                data: {
                    userId,
                    merchant: r.merchant,
                    amount: r.amount,
                    date: new Date(),
                    returnBy: r.returnBy ? new Date(now.getTime() + r.returnBy * 24 * 60 * 60 * 1000) : null,
                    warrantyUntil: r.warranty ? new Date(now.getTime() + r.warranty * 24 * 60 * 60 * 1000) : null,
                    reimbursable: false,
                },
            });
        }

        return NextResponse.json({
            success: true,
            seeded: {
                categories: categoryData.length,
                transactions: demoTransactions.length,
                goals: demoGoals.length,
                receipts: demoReceipts.length,
            },
        });
    } catch (err) {
        console.error("[api/dev/seed] Error:", err);
        return NextResponse.json({ error: "Failed to seed demo data" }, { status: 500 });
    }
}
