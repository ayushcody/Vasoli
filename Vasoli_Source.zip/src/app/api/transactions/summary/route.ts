import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

/** GET /api/transactions/summary — Transaction summary + freshness info */
export async function GET() {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const [totalIncome, totalExpense, lastImport, transactionCount, pendingCount] = await Promise.all([
            prisma.transaction.aggregate({
                where: { userId: user.id, type: "INCOME" },
                _sum: { amount: true },
            }),
            prisma.transaction.aggregate({
                where: { userId: user.id, type: "EXPENSE" },
                _sum: { amount: true },
            }),
            prisma.importBatch.findFirst({
                where: { userId: user.id },
                orderBy: { importedAt: "desc" },
            }),
            prisma.transaction.count({ where: { userId: user.id } }),
            prisma.transaction.count({ where: { userId: user.id, status: "pending" } }),
        ]);

        return NextResponse.json({
            totalIncome: totalIncome._sum.amount || 0,
            totalExpense: totalExpense._sum.amount || 0,
            balance: (totalIncome._sum.amount || 0) - (totalExpense._sum.amount || 0),
            transactionCount,
            pendingCount,
            lastImportDate: lastImport?.importedAt || null,
            lastImportBank: lastImport?.bankName || null,
        });
    } catch (err) {
        console.error("[api/transactions/summary] Error:", err);
        // Return safe defaults so the dashboard doesn't crash
        return NextResponse.json({
            totalIncome: 0,
            totalExpense: 0,
            balance: 0,
            transactionCount: 0,
            pendingCount: 0,
            lastImportDate: null,
            lastImportBank: null,
        });
    }
}

