import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const { searchParams } = new URL(req.url);
        const type = searchParams.get("type") || undefined;
        const categoryId = searchParams.get("categoryId") || undefined;
        const startDate = searchParams.get("startDate");
        const endDate = searchParams.get("endDate");
        const status = searchParams.get("status") || undefined;

        const where: any = { userId: user.id };
        if (type) where.type = type;
        if (categoryId) where.categoryId = categoryId;
        if (status) where.status = status;
        if (startDate || endDate) {
            where.date = {};
            if (startDate) where.date.gte = new Date(startDate);
            if (endDate) where.date.lte = new Date(endDate);
        }

        const transactions = await prisma.transaction.findMany({
            where,
            include: { category: true, importBatch: true },
            orderBy: { date: "desc" },
            take: 100,
        });

        return NextResponse.json(transactions);
    } catch (err) {
        console.error("[api/transactions] GET error:", err);
        return NextResponse.json([]);
    }
}

export async function POST(req: NextRequest) {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();

    const transaction = await prisma.transaction.create({
        data: {
            userId: user.id,
            date: new Date(body.date),
            amount: body.amount,
            currency: body.currency || "INR",
            merchantRaw: body.merchant || null,
            merchantNorm: body.merchant?.toLowerCase().trim() || null,
            description: body.description || null,
            type: body.type || "EXPENSE",
            status: body.status || "posted",
            provenance: body.provenance || "manual",
            categoryId: body.categoryId || null,
            tags: body.tags || [],
            notes: body.notes || null,
            upiRef: body.upiRef || null,
        },
        include: { category: true },
    });

    // Create audit event
    await prisma.transactionEvent.create({
        data: {
            userId: user.id,
            transactionId: transaction.id,
            type: "created",
            payloadJson: JSON.stringify({ provenance: transaction.provenance }),
        },
    });

    return NextResponse.json(transaction, { status: 201 });
}
