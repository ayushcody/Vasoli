import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const receipts = await prisma.receipt.findMany({
            where: { userId: user.id },
            include: { transaction: { include: { category: true } } },
            orderBy: { createdAt: "desc" },
        });

        return NextResponse.json(receipts);
    } catch (err) {
        console.error("[api/receipts] GET error:", err);
        return NextResponse.json([]);
    }
}

export async function POST(req: NextRequest) {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const body = await req.json();

        const receipt = await prisma.receipt.create({
            data: {
                userId: user.id,
                encryptedBlobPath: body.encryptedBlobPath || null,
                ocrEncryptedJson: body.ocrEncryptedJson || null,
                returnBy: body.returnBy ? new Date(body.returnBy) : null,
                warrantyUntil: body.warrantyUntil ? new Date(body.warrantyUntil) : null,
                reimbursable: body.reimbursable || false,
                merchant: body.merchant || null,
                amount: body.amount || null,
                date: body.date ? new Date(body.date) : null,
            },
        });

        if (body.amount && body.date) {
            const matchDate = new Date(body.date);
            const dayBefore = new Date(matchDate);
            dayBefore.setDate(dayBefore.getDate() - 2);
            const dayAfter = new Date(matchDate);
            dayAfter.setDate(dayAfter.getDate() + 2);

            const match = await prisma.transaction.findFirst({
                where: {
                    userId: user.id,
                    amount: body.amount,
                    date: { gte: dayBefore, lte: dayAfter },
                    receiptId: null,
                },
            });

            if (match) {
                await prisma.transaction.update({
                    where: { id: match.id },
                    data: { receiptId: receipt.id },
                });

                await prisma.transactionEvent.create({
                    data: {
                        userId: user.id,
                        transactionId: match.id,
                        type: "matched_receipt",
                        payloadJson: JSON.stringify({ receiptId: receipt.id }),
                    },
                });
            }
        }

        return NextResponse.json(receipt, { status: 201 });
    } catch (err) {
        console.error("[api/receipts] POST error:", err);
        return NextResponse.json(
            { error: "Database unavailable. Please try again later." },
            { status: 503 }
        );
    }
}
