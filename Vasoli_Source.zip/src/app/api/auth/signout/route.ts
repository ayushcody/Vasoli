import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function POST() {
    try {
        const supabase = createClient();
        await supabase.auth.signOut();
        return NextResponse.json({ message: "Signed out" }, { status: 200 });
    } catch (err) {
        console.error("[auth/signout] Error:", err);
        return NextResponse.json({ error: "Sign out failed" }, { status: 500 });
    }
}

