import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
    try {
        const supabase = createClient();
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const goals = await prisma.goal.findMany({
            where: { userId: user.id },
            include: { contributions: true, linkedCategory: true },
            orderBy: { createdAt: "desc" },
        });

        return NextResponse.json(goals);
    } catch (err) {
        console.error("[api/goals] GET error:", err);
        return NextResponse.json([]);
    }
}

export async function POST(req: NextRequest) {
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();

    const goal = await prisma.goal.create({
        data: {
            userId: user.id,
            name: body.name,
            description: body.description || null,
            targetAmount: body.targetAmount,
            cadence: body.cadence || null,
            dueDate: body.dueDate ? new Date(body.dueDate) : null,
            color: body.color || null,
            icon: body.icon || null,
            linkedCategoryId: body.linkedCategoryId || null,
        },
    });

    return NextResponse.json(goal, { status: 201 });
}
