"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useParams, useRouter } from "next/navigation";
import {
    BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell
} from "recharts";
import { ChevronLeft, ChevronRight, TrendingDown, TrendingUp, Flame, Target, AlertTriangle, Zap } from "lucide-react";

interface ZineData {
    period: string;
    totalSpent: number;
    totalIncome: number;
    transactionCount: number;
    topCategories: { name: string; icon: string; total: number }[];
    biggestSpend: { merchant: string; amount: number; date: string } | null;
    streak: number;
    savedVsPrev: number;
    leak: { category: string; increase: number } | null;
}

const CARD_COLORS = ["var(--mustard)", "var(--teal)", "var(--cobalt)", "var(--cta)", "var(--grape)", "var(--pink)"];

export default function ZinePage() {
    const params = useParams();
    const router = useRouter();
    const period = params.period as string;
    const [data, setData] = useState<ZineData | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch(`/api/zine/${period}`)
            .then((r) => r.json())
            .then((d) => { setData(d); setLoading(false); });
    }, [period]);

    const navigateMonth = (delta: number) => {
        const [y, m] = period.split("-").map(Number);
        const d = new Date(y, m - 1 + delta);
        router.push(`/app/zine/${d.toISOString().slice(0, 7)}`);
    };

    const monthLabel = new Date(period + "-01").toLocaleDateString("en-IN", {
        month: "long", year: "numeric",
    });

    if (loading) return <div className="p-8 text-center text-taupe">Loading your zine...</div>;
    if (!data) return <div className="p-8 text-center text-taupe">No data for this month.</div>;

    const cards = [
        // Card 1: Overview
        {
            title: "Monthly Overview",
            icon: "📊",
            content: (
                <div className="grid grid-cols-2 gap-4 mt-3">
                    <div><div className="text-2xl font-bold font-serif tabular-nums">₹{data.totalSpent.toLocaleString("en-IN")}</div><div className="text-xs text-taupe">Spent</div></div>
                    <div><div className="text-2xl font-bold font-serif tabular-nums text-success">₹{data.totalIncome.toLocaleString("en-IN")}</div><div className="text-xs text-taupe">Earned</div></div>
                </div>
            ),
        },
        // Card 2: Top Categories
        {
            title: "Where it went",
            icon: "🏷️",
            content: data.topCategories.length > 0 ? (
                <div className="mt-3 space-y-3">
                    {data.topCategories.map((cat, i) => (
                        <div key={cat.name} className="flex items-center gap-3">
                            <span className="text-lg">{cat.icon}</span>
                            <div className="flex-1">
                                <div className="flex justify-between text-sm">
                                    <span className="font-medium text-ink">{cat.name}</span>
                                    <span className="tabular-nums">₹{cat.total.toLocaleString("en-IN")}</span>
                                </div>
                                <div className="h-2 bg-paper-1 rounded-full mt-1 overflow-hidden">
                                    <div
                                        className="h-full rounded-full"
                                        style={{
                                            width: `${(cat.total / data.totalSpent) * 100}%`,
                                            backgroundColor: CARD_COLORS[i] || "var(--taupe)",
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : <p className="text-sm text-taupe mt-2">Not enough data yet.</p>,
        },
        // Card 3: Biggest Spend
        {
            title: "Biggest Spend",
            icon: "💸",
            content: data.biggestSpend ? (
                <div className="mt-3">
                    <div className="text-2xl font-bold font-serif tabular-nums mb-1">
                        ₹{data.biggestSpend.amount.toLocaleString("en-IN")}
                    </div>
                    <div className="text-sm text-taupe">
                        {data.biggestSpend.merchant || "Unknown"} ·{" "}
                        {new Date(data.biggestSpend.date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                    </div>
                </div>
            ) : <p className="text-sm text-taupe mt-2">No expenses this month.</p>,
        },
        // Card 4: Streak
        {
            title: data.streak >= 5 ? "Nice streak! 🔥" : "Logging activity",
            icon: "📅",
            content: (
                <div className="mt-3">
                    <div className="text-3xl font-bold font-serif">{data.streak}</div>
                    <div className="text-sm text-taupe">
                        {data.streak >= 5 ? `days logged — keep it going!` : `days logged this month`}
                    </div>
                </div>
            ),
        },
        // Card 5: One Leak
        ...(data.leak ? [{
            title: "Category to watch",
            icon: "⚠️",
            content: (
                <div className="mt-3">
                    <div className="text-sm font-medium text-ink">{data.leak!.category}</div>
                    <div className="text-lg font-bold font-serif text-cta tabular-nums">
                        +₹{data.leak!.increase.toLocaleString("en-IN")}
                    </div>
                    <div className="text-xs text-taupe">vs last month</div>
                </div>
            ),
        }] : []),
        // Card 6: One Win
        {
            title: data.savedVsPrev > 0 ? "You saved more! 🎉" : "Spending comparison",
            icon: data.savedVsPrev > 0 ? "🏆" : "📈",
            content: (
                <div className="mt-3">
                    <div className={`text-2xl font-bold font-serif tabular-nums ${data.savedVsPrev > 0 ? "text-success" : "text-cta"}`}>
                        {data.savedVsPrev > 0 ? "+" : ""}₹{data.savedVsPrev.toLocaleString("en-IN")}
                    </div>
                    <div className="text-sm text-taupe">
                        {data.savedVsPrev > 0 ? "saved compared to last month" : "more spent than last month"}
                    </div>
                </div>
            ),
        },
    ];

    return (
        <div className="p-8">
            {/* Header with navigation */}
            <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center justify-between mb-8"
            >
                <div>
                    <h1 className="font-serif text-3xl font-bold text-ink mb-1">Ledger Zine</h1>
                    <p className="text-taupe">Your monthly financial story</p>
                </div>
                <div className="flex items-center gap-2">
                    <button
                        onClick={() => navigateMonth(-1)}
                        className="border-brutal rounded-neo p-2 bg-paper-2 hover:bg-paper-2/80 transition-all"
                    >
                        <ChevronLeft size={18} />
                    </button>
                    <span className="font-serif font-bold text-ink px-3">{monthLabel}</span>
                    <button
                        onClick={() => navigateMonth(1)}
                        className="border-brutal rounded-neo p-2 bg-paper-2 hover:bg-paper-2/80 transition-all"
                    >
                        <ChevronRight size={18} />
                    </button>
                </div>
            </motion.div>

            {/* Card Grid */}
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {cards.map((card, i) => (
                    <motion.div
                        key={card.title}
                        initial={{ opacity: 0, y: 30, rotate: -1 }}
                        animate={{ opacity: 1, y: 0, rotate: 0 }}
                        transition={{ delay: i * 0.1, type: "spring", stiffness: 200 }}
                        whileHover={{ y: -4, rotate: 0.5 }}
                        className="border-brutal-thick rounded-neo-md bg-paper-2 p-6 shadow-brutal"
                    >
                        <div className="flex items-center gap-2">
                            <span className="text-xl">{card.icon}</span>
                            <h3 className="font-serif text-lg font-bold text-ink">{card.title}</h3>
                        </div>
                        {card.content}
                    </motion.div>
                ))}
            </div>
        </div>
    );
}
