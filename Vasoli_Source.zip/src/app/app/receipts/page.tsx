"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, Unlock, Upload, Camera, Calendar, Shield, Package, FileDown, Loader2, Scan } from "lucide-react";
import { deriveKey, generateSalt, encryptString, decryptString, toHex, fromHex } from "@/lib/crypto/vault";
import { scanReceipt } from "@/lib/ocr/receipt-scanner";
import { toast } from "sonner";

interface Receipt {
    id: string;
    merchant: string | null;
    amount: number | null;
    date: string | null;
    returnBy: string | null;
    warrantyUntil: string | null;
    reimbursable: boolean;
    ocrEncryptedJson: string | null;
    encryptedBlobPath: string | null;
    transaction: { id: string; description: string; category: { name: string; icon: string } | null } | null;
    createdAt: string;
}

type Tab = "all" | "returns" | "warranties" | "export";

export default function ReceiptsPage() {
    const [receipts, setReceipts] = useState<Receipt[]>([]);
    const [loading, setLoading] = useState(true);
    const [isScanning, setIsScanning] = useState(false);
    const [tab, setTab] = useState<Tab>("all");
    const [vaultKey, setVaultKey] = useState<CryptoKey | null>(null);
    const [passphrase, setPassphrase] = useState("");
    const [unlocking, setUnlocking] = useState(false);
    const [showUnlockModal, setShowUnlockModal] = useState(false);
    const fileRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        fetch("/api/receipts")
            .then((r) => r.json())
            .then((data) => { setReceipts(data); setLoading(false); });
    }, []);

    const handleUnlock = async () => {
        if (!passphrase) return;
        setUnlocking(true);
        try {
            const salt = generateSalt();
            const key = await deriveKey(passphrase, salt);
            setVaultKey(key);
            setShowUnlockModal(false);
            setPassphrase("");
            toast.success("Vault unlocked successfully");
        } catch {
            toast.error("Failed to unlock vault");
        } finally {
            setUnlocking(false);
        }
    };

    const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsScanning(true);
        try {
            // 1. Scan image
            const scannedData = await scanReceipt(file);

            // 2. Encrypt if vault is open, else send raw json string
            let ocrPayload = JSON.stringify(scannedData);
            if (vaultKey) {
                // encryptString returns a single hex-encoded string containing IV + Ciphertext
                ocrPayload = await encryptString(ocrPayload, vaultKey);
            }

            // 3. Post to API
            const res = await fetch("/api/receipts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    merchant: scannedData.merchant,
                    amount: scannedData.amount,
                    date: scannedData.date,
                    returnBy: scannedData.returnBy,
                    warrantyUntil: scannedData.warrantyUntil,
                    reimbursable: false,
                    ocrEncryptedJson: ocrPayload,
                }),
            });

            if (!res.ok) throw new Error("Failed to save receipt");

            const newReceipt = await res.json();
            setReceipts((prev) => [newReceipt, ...prev]);

            toast.success(`Receipt from ${scannedData.merchant || 'Unknown'} scanned!`, {
                description: scannedData.amount ? `Total: ₹${scannedData.amount.toLocaleString('en-IN')}` : undefined
            });
        } catch (err) {
            console.error(err);
            toast.error("Failed to scan receipt");
        } finally {
            setIsScanning(false);
            if (fileRef.current) fileRef.current.value = "";
        }
    };

    const filtered = receipts.filter((r) => {
        if (tab === "returns") return r.returnBy && new Date(r.returnBy) > new Date();
        if (tab === "warranties") return r.warrantyUntil && new Date(r.warrantyUntil) > new Date();
        if (tab === "export") return r.reimbursable;
        return true;
    });

    const tabs: { key: Tab; label: string; icon: any }[] = [
        { key: "all", label: "All Receipts", icon: Camera },
        { key: "returns", label: "Returns", icon: Package },
        { key: "warranties", label: "Warranties", icon: Shield },
        { key: "export", label: "Export", icon: FileDown },
    ];

    return (
        <div className="p-8">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h1 className="font-serif text-3xl font-bold text-ink mb-1">Receipt Vault</h1>
                        <p className="text-taupe">Encrypted, on-device receipt management</p>
                    </div>
                    <div className="flex gap-3">
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setShowUnlockModal(true)}
                            className={`border-brutal rounded-neo px-4 py-2 text-sm font-medium flex items-center gap-2 transition-all ${vaultKey
                                ? "bg-success/15 text-success"
                                : "bg-paper-2 text-taupe hover:bg-paper-2/80"
                                }`}
                        >
                            {vaultKey ? <Unlock size={16} /> : <Lock size={16} />}
                            {vaultKey ? "Vault Unlocked" : "Unlock Vault"}
                        </motion.button>
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => fileRef.current?.click()}
                            disabled={isScanning}
                            className="border-brutal-thick rounded-neo bg-cta text-ink px-4 py-2 text-sm font-semibold flex items-center gap-2 shadow-brutal-sm hover:shadow-brutal transition-all disabled:opacity-50"
                        >
                            {isScanning ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
                            {isScanning ? "Scanning..." : "Scan Receipt"}
                        </motion.button>
                        <input
                            ref={fileRef}
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleFileSelect}
                        />
                    </div>
                </div>
            </motion.div>

            {/* Scanning Overlay Placeholder */}
            {isScanning && (
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mb-6 border-brutal-thick rounded-neo-md bg-teal/20 border-teal p-6 text-center animate-pulse flex flex-col items-center justify-center"
                >
                    <Scan size={32} className="mb-3 text-teal animate-bounce" />
                    <h3 className="font-serif font-bold text-lg text-ink">Scanning receipt securely on-device with OCR...</h3>
                    <p className="text-sm text-taupe">Extracting merchant, amount, dates, and warranties.</p>
                </motion.div>
            )}

            {/* Tabs */}
            <div className="flex gap-2 mb-6">
                {tabs.map((t) => (
                    <button
                        key={t.key}
                        onClick={() => setTab(t.key)}
                        className={`border-brutal rounded-neo px-4 py-2 text-sm font-medium flex items-center gap-2 transition-all ${tab === t.key
                            ? "bg-ink text-paper-1 shadow-brutal-sm"
                            : "bg-paper-2 text-taupe hover:bg-paper-2/80"
                            }`}
                    >
                        <t.icon size={14} /> {t.label}
                    </button>
                ))}
            </div>

            {/* Receipt Grid */}
            {loading ? (
                <div className="text-center py-12 text-taupe">Loading receipts...</div>
            ) : filtered.length === 0 && !isScanning ? (
                <div className="border-brutal-thick rounded-neo-md bg-paper-2 p-12 shadow-brutal text-center">
                    <div className="text-5xl mb-4">🧾</div>
                    <p className="text-taupe">
                        {tab === "all" ? "No receipts yet. Scan one to get started!" :
                            tab === "returns" ? "No upcoming returns." :
                                tab === "warranties" ? "No active warranties." :
                                    "No reimbursable receipts."}
                    </p>
                </div>
            ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {filtered.map((receipt, i) => (
                        <motion.div
                            key={receipt.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.05 }}
                            className="border-brutal-thick rounded-neo-md bg-paper-2 p-5 shadow-brutal hover:shadow-brutal-hover transition-all"
                        >
                            {!vaultKey && receipt.ocrEncryptedJson && receipt.ocrEncryptedJson !== "null" ? (
                                <div className="text-center py-4">
                                    <Lock className="mx-auto mb-2 text-taupe" size={24} />
                                    <p className="text-sm text-taupe">Unlock vault to view</p>
                                </div>
                            ) : (
                                <>
                                    <div className="flex items-center justify-between mb-3">
                                        <span className="font-medium text-ink text-sm truncate">
                                            {receipt.merchant || "Unknown Merchant"}
                                        </span>
                                        {receipt.reimbursable && (
                                            <span className="text-xs border-brutal rounded-full px-2 py-0.5 bg-grape/15 text-grape">
                                                Reimbursable
                                            </span>
                                        )}
                                    </div>
                                    {receipt.amount && (
                                        <div className="text-xl font-bold font-serif text-ink tabular-nums mb-2">
                                            ₹{receipt.amount.toLocaleString("en-IN")}
                                        </div>
                                    )}
                                    <div className="space-y-1 text-xs text-taupe">
                                        {receipt.date && (
                                            <div className="flex items-center gap-1">
                                                <Calendar size={12} /> {new Date(receipt.date).toLocaleDateString("en-IN")}
                                            </div>
                                        )}
                                        {receipt.returnBy && (
                                            <div className="flex items-center gap-1 text-warning">
                                                <Package size={12} /> Return by: {new Date(receipt.returnBy).toLocaleDateString("en-IN")}
                                            </div>
                                        )}
                                        {receipt.warrantyUntil && (
                                            <div className="flex items-center gap-1 text-cobalt">
                                                <Shield size={12} /> Warranty: {new Date(receipt.warrantyUntil).toLocaleDateString("en-IN")}
                                            </div>
                                        )}
                                    </div>
                                    {receipt.transaction && (
                                        <div className="mt-3 pt-3 border-t border-taupe/20 text-xs text-taupe">
                                            Linked: {receipt.transaction.category?.icon} {receipt.transaction.description}
                                        </div>
                                    )}
                                </>
                            )}
                        </motion.div>
                    ))}
                </div>
            )}

            {/* Unlock Modal */}
            <AnimatePresence>
                {showUnlockModal && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-ink/50 flex items-center justify-center z-50 p-4"
                        onClick={() => setShowUnlockModal(false)}
                    >
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            onClick={(e) => e.stopPropagation()}
                            className="border-brutal-thick rounded-neo-md bg-paper-1 p-6 shadow-brutal w-full max-w-sm"
                        >
                            <h3 className="font-serif text-xl font-bold text-ink mb-2">🔐 Unlock Vault</h3>
                            <p className="text-sm text-taupe mb-4">
                                Enter your passphrase to decrypt receipts. This never leaves your device.
                            </p>
                            <input
                                type="password"
                                value={passphrase}
                                onChange={(e) => setPassphrase(e.target.value)}
                                placeholder="Your vault passphrase"
                                className="w-full border-brutal rounded-neo px-4 py-3 bg-paper-2 text-ink placeholder:text-taupe focus:outline-none focus:ring-2 focus:ring-ink mb-4"
                                onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
                            />
                            <motion.button
                                onClick={handleUnlock}
                                disabled={unlocking || !passphrase}
                                whileHover={{ scale: 1.01 }}
                                whileTap={{ scale: 0.98 }}
                                className="w-full border-brutal-thick rounded-neo bg-cta text-ink font-semibold py-3 flex items-center justify-center gap-2 shadow-brutal-sm disabled:opacity-40"
                            >
                                {unlocking ? <Loader2 size={16} className="animate-spin" /> : <Unlock size={16} />}
                                {unlocking ? "Unlocking..." : "Unlock"}
                            </motion.button>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
