"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/browser";
import { motion } from "framer-motion";
import {
    IndianRupee, TrendingUp, TrendingDown, Target,
    Receipt, Clock, FileSpreadsheet, Plus, ArrowRight
} from "lucide-react";
import Link from "next/link";

interface Summary {
    totalIncome: number;
    totalExpense: number;
    balance: number;
    transactionCount: number;
    pendingCount: number;
    lastImportDate: string | null;
    lastImportBank: string | null;
}

interface Transaction {
    id: string;
    date: string;
    amount: number;
    type: string;
    merchantRaw: string | null;
    description: string | null;
    category: { name: string; icon: string } | null;
}

interface Goal {
    id: string;
    name: string;
    targetAmount: number;
    currentAmount: number;
    icon: string | null;
}

export default function DashboardPage() {
    const supabase = createClient();
    const [user, setUser] = useState<any>(null);
    const [summary, setSummary] = useState<Summary | null>(null);
    const [recentTxns, setRecentTxns] = useState<Transaction[]>([]);
    const [goals, setGoals] = useState<Goal[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchAll = async () => {
            const { data: { user } } = await supabase.auth.getUser();
            setUser(user);

            try {
                const [summaryRes, txnRes, goalsRes] = await Promise.all([
                    fetch("/api/transactions/summary").then(r => r.ok ? r.json() : null),
                    fetch("/api/transactions?limit=5").then(r => r.ok ? r.json() : []),
                    fetch("/api/goals").then(r => r.ok ? r.json() : []),
                ]);
                if (summaryRes) setSummary(summaryRes);
                setRecentTxns(Array.isArray(txnRes) ? txnRes.slice(0, 5) : []);
                setGoals(Array.isArray(goalsRes) ? goalsRes : []);
            } catch {
                // API routes may fail if DB is unreachable — show empty state
            }
            setLoading(false);
        };
        fetchAll();
    }, []);

    const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;

    const cards = [
        {
            label: "Balance",
            value: summary ? fmt(summary.balance) : "₹0",
            icon: IndianRupee,
            color: "bg-teal/20",
            iconColor: "text-teal",
        },
        {
            label: "Income",
            value: summary ? fmt(summary.totalIncome) : "₹0",
            icon: TrendingUp,
            color: "bg-success/20",
            iconColor: "text-success",
        },
        {
            label: "Expenses",
            value: summary ? fmt(summary.totalExpense) : "₹0",
            icon: TrendingDown,
            color: "bg-cta/20",
            iconColor: "text-cta",
        },
        {
            label: "Goals",
            value: goals.length > 0 ? `${goals.filter(g => (g as any).active !== false).length} active` : "0 active",
            icon: Target,
            color: "bg-cobalt/20",
            iconColor: "text-cobalt",
        },
    ];

    return (
        <div className="p-8">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
                <h1 className="font-serif text-3xl font-bold text-ink mb-1">
                    {user?.user_metadata?.name ? `Namaste, ${user.user_metadata.name}` : "Dashboard"}
                </h1>
                <p className="text-taupe mb-8">Here's your financial overview</p>
            </motion.div>

            {/* Stat Cards */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
                {cards.map((card, i) => (
                    <motion.div
                        key={card.label}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="border-brutal-thick rounded-neo-md bg-paper-2 p-6 shadow-brutal hover:shadow-brutal-hover transition-all"
                    >
                        <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-medium text-taupe">{card.label}</span>
                            <div className={`p-2 rounded-neo ${card.color}`}>
                                <card.icon className={`h-4 w-4 ${card.iconColor}`} />
                            </div>
                        </div>
                        <div className="text-2xl font-bold font-serif text-ink tabular-nums">
                            {loading ? "..." : card.value}
                        </div>
                    </motion.div>
                ))}
            </div>

            {/* Data Freshness */}
            {summary && (
                <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="border-brutal rounded-neo bg-mustard/20 p-4 mb-6 flex items-center justify-between gap-4 flex-wrap"
                >
                    <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-2">
                            <div className={`h-2 w-2 rounded-full ${summary.lastImportDate ? "bg-success" : "bg-warning"}`} />
                            <span className="text-ink font-medium">
                                {summary.lastImportDate
                                    ? `Last import: ${summary.lastImportBank || "Unknown"}`
                                    : "No statement imported yet"}
                            </span>
                        </div>
                        {summary.pendingCount > 0 && (
                            <div className="flex items-center gap-1 text-warning">
                                <Clock size={14} />
                                <span>{summary.pendingCount} pending</span>
                            </div>
                        )}
                    </div>
                    <span className="text-sm text-taupe">{summary.transactionCount} transactions</span>
                </motion.div>
            )}

            <div className="grid gap-6 lg:grid-cols-2">
                {/* Recent Transactions */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="border-brutal-thick rounded-neo-md bg-paper-2 p-6 shadow-brutal"
                >
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="font-serif text-xl font-bold text-ink">Recent Transactions</h2>
                        <Link href="/app/transactions" className="text-xs text-cobalt font-medium hover:underline flex items-center gap-1">
                            View all <ArrowRight size={12} />
                        </Link>
                    </div>
                    {loading ? (
                        <p className="text-taupe text-sm">Loading...</p>
                    ) : recentTxns.length === 0 ? (
                        <div className="text-center py-6">
                            <div className="text-4xl mb-2">📋</div>
                            <p className="text-taupe text-sm mb-3">No transactions yet</p>
                            <Link
                                href="/app/transactions"
                                className="inline-flex items-center gap-1 text-xs font-medium text-cobalt hover:underline"
                            >
                                <Plus size={12} /> Add your first transaction
                            </Link>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            {recentTxns.map((txn) => (
                                <div key={txn.id} className="flex items-center gap-3 py-2 border-b border-taupe/10 last:border-0">
                                    <span className="text-lg">{txn.category?.icon || "📝"}</span>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium text-ink truncate">
                                            {txn.merchantRaw || txn.description || "Unknown"}
                                        </p>
                                        <p className="text-xs text-taupe">
                                            {new Date(txn.date).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                                            {txn.category && ` · ${txn.category.name}`}
                                        </p>
                                    </div>
                                    <span className={`font-bold font-serif text-sm tabular-nums ${txn.type === "INCOME" ? "text-success" : "text-ink"}`}>
                                        {txn.type === "INCOME" ? "+" : "-"}{fmt(txn.amount)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </motion.div>

                {/* Goals */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                    className="border-brutal-thick rounded-neo-md bg-paper-2 p-6 shadow-brutal"
                >
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="font-serif text-xl font-bold text-ink">Goals</h2>
                        <Link href="/app/goals" className="text-xs text-cobalt font-medium hover:underline flex items-center gap-1">
                            View all <ArrowRight size={12} />
                        </Link>
                    </div>
                    {loading ? (
                        <p className="text-taupe text-sm">Loading...</p>
                    ) : goals.length === 0 ? (
                        <div className="text-center py-6">
                            <div className="text-4xl mb-2">🎯</div>
                            <p className="text-taupe text-sm mb-3">No goals set yet</p>
                            <Link
                                href="/app/goals"
                                className="inline-flex items-center gap-1 text-xs font-medium text-cobalt hover:underline"
                            >
                                <Plus size={12} /> Create your first goal
                            </Link>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {goals.slice(0, 4).map((goal) => {
                                const progress = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
                                return (
                                    <div key={goal.id} className="space-y-1">
                                        <div className="flex items-center justify-between text-sm">
                                            <span className="font-medium text-ink">{goal.icon || "🎯"} {goal.name}</span>
                                            <span className="text-taupe tabular-nums">{fmt(goal.currentAmount)} / {fmt(goal.targetAmount)}</span>
                                        </div>
                                        <div className="w-full h-2 bg-paper-1 rounded-full border border-taupe/20">
                                            <div
                                                className="h-full bg-teal rounded-full transition-all"
                                                style={{ width: `${progress}%` }}
                                            />
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </motion.div>
            </div>
        </div>
    );
}
