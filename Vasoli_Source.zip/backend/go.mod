module vasoli-backend

go 1.25.0

require (
	connectrpc.com/connect v1.19.1
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/google/uuid v1.6.0
	golang.org/x/net v0.51.0
	google.golang.org/protobuf v1.36.11
)

require golang.org/x/text v0.34.0 // indirect
