import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const categories = [
    // Expenses
    { name: "Food & Dining", icon: "🍛", color: "#F6DD4D", type: "EXPENSE", isDefault: true },
    { name: "Groceries", icon: "🛒", color: "#2EC4B6", type: "EXPENSE", isDefault: true },
    { name: "Transport", icon: "🚌", color: "#3D5AFE", type: "EXPENSE", isDefault: true },
    { name: "Rent", icon: "🏠", color: "#FD712C", type: "EXPENSE", isDefault: true },
    { name: "Utilities", icon: "💡", color: "#8B5CF6", type: "EXPENSE", isDefault: true },
    { name: "Mobile & Internet", icon: "📱", color: "#FF4D8D", type: "EXPENSE", isDefault: true },
    { name: "Shopping", icon: "🛍️", color: "#E63946", type: "EXPENSE", isDefault: true },
    { name: "Education", icon: "📚", color: "#3D5AFE", type: "EXPENSE", isDefault: true },
    { name: "Medical", icon: "🏥", color: "#E63946", type: "EXPENSE", isDefault: true },
    { name: "Entertainment", icon: "🎬", color: "#8B5CF6", type: "EXPENSE", isDefault: true },
    { name: "Personal Care", icon: "💈", color: "#FF4D8D", type: "EXPENSE", isDefault: true },
    { name: "Subscriptions", icon: "🔄", color: "#FD712C", type: "EXPENSE", isDefault: true },
    { name: "Gifts & Donations", icon: "🎁", color: "#F6DD4D", type: "EXPENSE", isDefault: true },
    { name: "Other Expense", icon: "📝", color: "#A2897D", type: "EXPENSE", isDefault: true },
    // Income
    { name: "Salary", icon: "💰", color: "#2EC4B6", type: "INCOME", isDefault: true },
    { name: "Pocket Money", icon: "👨‍👩‍👧", color: "#F6DD4D", type: "INCOME", isDefault: true },
    { name: "Freelance", icon: "💻", color: "#3D5AFE", type: "INCOME", isDefault: true },
    { name: "Stipend", icon: "🎓", color: "#8B5CF6", type: "INCOME", isDefault: true },
    { name: "Cashback & Rewards", icon: "🎉", color: "#FD712C", type: "INCOME", isDefault: true },
    { name: "Other Income", icon: "📥", color: "#A2897D", type: "INCOME", isDefault: true },
];

async function main() {
    console.log("Seeding categories...");

    for (const cat of categories) {
        await prisma.category.upsert({
            where: { name: cat.name },
            update: {},
            create: cat,
        });
    }

    console.log(`Seeded ${categories.length} categories.`);
}

main()
    .then(() => prisma.$disconnect())
    .catch((e) => {
        console.error(e);
        prisma.$disconnect();
        process.exit(1);
    });
